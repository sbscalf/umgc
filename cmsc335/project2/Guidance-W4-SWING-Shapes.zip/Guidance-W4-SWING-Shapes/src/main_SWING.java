
import javax.swing.*;
import java.awt.GridLayout;
import java.text.DecimalFormat;
import java.util.regex.Pattern;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author omora
 */
public class main_SWING extends JFrame{
    
    // first row
    private JLabel jlblSelectShape = new JLabel("Select A Shape");
    private JLabel jlblInvisible0x1 = new JLabel();
    private JLabel jlblInvisible0x2 = new JLabel();
    private JLabel jlblInvisible0x3 = new JLabel();
    
    // second row
    private JComboBox<String> jcbSelectAShape = new JComboBox<String>();
    private JButton jbtnSelectShape = new JButton("Select Shape");
    private JLabel jlblEnterParam1 = new JLabel();
    private JTextField jtfEnterParam1 = new JTextField();

    // third row
    private JLabel jlblInvisible3x0  = new JLabel();
    private JLabel jlblInvisible3x1 = new JLabel();
    private JLabel jlblInvisible3x2 = new JLabel();
    private JButton jbtnDisplayShape = new JButton("Display Shape");

    // fourth row
    private JLabel jlblInvisible4x0  = new JLabel();
    private JLabel jlblInvisible4x1  = new JLabel();
    private JLabel jlblInvisible4x2  = new JLabel();
    private JLabel jlblAreaOrVolume = new JLabel(); 
    
    // fifth row
    private JLabel jlblInvisible5x0  = new JLabel();
    private JLabel jlblInvisible5x1  = new JLabel();
    private JLabel jlblInvisible5x2  = new JLabel();
    private JTextField jtfAreaOrVolume = new JTextField();     
    
    private String shape;
    DecimalFormat df = new DecimalFormat("0.00");
    
    public main_SWING () {
        
        setLayout(new GridLayout(0, 4,  5,  5));
        
        // first row
        add(jlblSelectShape);
        add(jlblInvisible0x1);
        add(jlblInvisible0x2);
        add(jlblInvisible0x3);
        
        // second row
        jcbSelectAShape.setModel(new javax.swing.DefaultComboBoxModel<>(new String[]
            { "Circle", "Sphere" }));
        add(jcbSelectAShape);
        add(jbtnSelectShape);
        add(jlblEnterParam1);
        add(jtfEnterParam1);
        
        // third row
        add(jlblInvisible3x0);
        add(jlblInvisible3x1);
        add(jlblInvisible3x2);
        add(jbtnDisplayShape);   

        // fourth row
        add(jlblInvisible5x0);
        add(jlblInvisible5x1);
        add(jlblInvisible5x2);
        add(jlblAreaOrVolume);
        
        // fifth row
        add(jlblInvisible4x0);
        add(jlblInvisible4x1);
        add(jlblInvisible4x2);
        add(jtfAreaOrVolume);         

  
        pack();
        
        
        jbtnSelectShape.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnSelectShapeActionPerformed(evt);
            }
        });
        

        jbtnDisplayShape.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jbtnDisplayShapeActionPerformed(evt);
            }
        });        
        
        
        
    }
    
    public static void main( String[] args) {
        JFrame frame = new main_SWING();
        frame.setTitle("SWING Shapes");
        //frame.setSize(800, 600);
        frame.setLocationRelativeTo(null);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setVisible(true);

    }
    
    
    private void jbtnSelectShapeActionPerformed(java.awt.event.ActionEvent evt) {     

        shape = String.valueOf(jcbSelectAShape.getSelectedItem());
        
        switch(shape){
            case "Circle":
                clearGUI();
                jlblEnterParam1.setText("Enter Radius");
                jtfEnterParam1.setVisible(true);
                break;
            case "Sphere":
                clearGUI();
                jlblEnterParam1.setText("Enter Radius");
                jtfEnterParam1.setVisible(true);                              
                break;
           
        }
    }  
    
    private void jbtnDisplayShapeActionPerformed(java.awt.event.ActionEvent evt) {                                         
        JFrame jFrame1 = new JFrame(shape);
        double radius;
        

        switch(shape){
            case "Circle":
                radius = Double.parseDouble(jtfEnterParam1.getText());
                jlblAreaOrVolume.setText("Area:");
                jtfAreaOrVolume.setText(df.format(Controller.getAreaOfCircle(radius)));
                jFrame1.add(new DrawCircle((int)radius));
                break;    
            case "Sphere":
                radius = Double.parseDouble(jtfEnterParam1.getText()); 
                jlblAreaOrVolume.setText("Volume:");
                jtfAreaOrVolume.setText(df.format(Controller.getVolumeOfSphere(radius)));
                jFrame1.add(new JLabel(new ImageIcon("Sphere.jpg")));
                break;

        }
        

        jFrame1.setLocationRelativeTo(null);
        jFrame1.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        jFrame1.setVisible(true);
        jFrame1.pack();
    }  
    
    
    private void clearGUI() {
        jlblEnterParam1.setText("");
        jtfEnterParam1.setText("");
              
        jlblAreaOrVolume.setText("");
        jtfAreaOrVolume.setText("");
        
        jlblAreaOrVolume.setText("");
        jtfAreaOrVolume.setText("");        
        
        jtfEnterParam1.setVisible(false);

    }
}
