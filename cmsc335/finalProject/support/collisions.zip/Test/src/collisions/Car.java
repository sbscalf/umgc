package collisions;

public class Car extends Sprite {
	
	private int velocity;

	public Car(int x, int y) {
		this(x, y, 10);
	}
	
	public Car(int x, int y, int velocity) {
		super(x, y);
		loadImage("/images/car2.png");
		this.velocity = velocity;
	}
	
	public void move() {
		this.x += velocity;
	}

}
