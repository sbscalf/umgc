package collisions;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;
import javax.swing.Timer;

public class TrafficPanel extends JPanel implements ActionListener {
	private static final long serialVersionUID = 1L;
	
	private Timer timer;
	private Car car;
	private Light light;
	private final int ICRAFT_X = 20;
	private final int ICRAFT_Y = 150;
	private final int B_WIDTH = 400;
	private final int B_HEIGHT = 300;
	private final int DELAY = 15;
	
	public TrafficPanel() {
		setFocusable(true);
		setBackground(new Color(153, 217, 234));
		setPreferredSize(new Dimension(B_WIDTH, B_HEIGHT));
		car = new Car(ICRAFT_X, ICRAFT_Y);
		light = new Light(ICRAFT_X + 250, ICRAFT_Y - 50);
		timer = new Timer(DELAY, this);
	}
	
	@Override
	public void paintComponent(Graphics g) {
		super.paintComponent(g);
		g.drawImage(car.getImage(), car.getX(), car.getY(), this);
		g.drawImage(light.getImage(), light.getX(), light.getY(), this);
		Toolkit.getDefaultToolkit().sync();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		car.move();
		checkCollisions();
		repaint();
		if (car.getX() > this.getWidth())
			System.exit(0);
	}
	
	private void checkCollisions() {
		if (light.isRed()) {
			Rectangle r = light.getBounds();
			Rectangle r1 = car.getBounds();
			if (r1.intersects(r)) {
				try { Thread.sleep(4000); } catch (InterruptedException e) {}
				light.changeLight();
			}
		}
	}
	
	public void startTimer() {
		timer.start();
	}

}
