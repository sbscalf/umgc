package collisions;

import java.awt.Container;
import java.awt.LayoutManager;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.OverlayLayout;
import javax.swing.SwingUtilities;

public class Program extends JFrame implements ActionListener {
	private static final long serialVersionUID = 1L;
	
	TrafficPanel p;
	
	public Program() {
		Container c = getContentPane();
		LayoutManager overlay = new OverlayLayout(c);
		c.setLayout(overlay);
		JButton start = new JButton("START");
		start.addActionListener(this);
		start.setAlignmentX(0.0f);
		start.setAlignmentY(0.0f);
		c.add(start);
		p = new TrafficPanel();
		c.add(p);
		setResizable(false);
		pack();
		
		setTitle("Traffic");
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		p.startTimer();
	}
	
	public static void main(String[] args) {
		SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				Program a = new Program();
				a.setVisible(true);
			}
		});
	}

}
