package collisions;

public class Light extends Sprite {
	
	enum Color { GREEN, YELLOW, RED };
	
	private Color currentColor;
	
	public Light(int x, int y) {
		super(x, y);
		loadImage("/images/redLight.png");
		currentColor = Color.RED;
	}
	
	public boolean isRed() {
		return currentColor == Color.RED;
	}
	
	public void changeLight() {
		if (currentColor == Color.RED) {
			loadImage("/images/greenLight.png");
			currentColor = Color.GREEN;
		}
	}
	
}
