

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;
import java.util.regex.Pattern;


public class Main {
    
        static Scanner scan = new Scanner(System.in);  
        
	public static void main(String args[]) {
			
		
		boolean finished = false;  
		
		while(!finished) {
			displayOptions();  
			
			switch(getSelection() ) {
				case 10: {
					finished = true;
					continue;
				}
				case 1: { 
					System.out.println("You have selected a Circle");
					System.out.print("Enter the radius: ");
                                        double radius = getDoubleValue();
					System.out.println("Area of " + "Circle" + " = " + Controller.getAreaOfCircle(radius));
					break;
				}

				default: { 
					break;
				}
			}
			

			System.out.println("\nContinue? (Y or N)");
                        String answer = scan.next();
                        while (!answer.equalsIgnoreCase("Y") && !answer.equalsIgnoreCase("N")) {
                            System.out.println(" Please enter Y or N only");
                            answer = scan.next();
                        }
                        if (answer.equalsIgnoreCase("n"))
                            finished = true;

		} 
		
		
		System.out.println("Thank you for using the program. Today is "
		+ (new SimpleDateFormat("MMMM dd 'at' h:mma").format(Calendar.getInstance().getTime())));
		System.exit(0);
		
	}
	
	private static void displayOptions() {
		System.out.println(
                        "Select from the menu below:" + "\n\n" +
                        "1. Construct a Circle" +  "\n");

                System.out.print("\nYour Selection: ");
	}
	
        
        private static int getSelection() {
            
            String selection;
            
            selection = scan.next();
                     
            // TODO 
            // Need to validate user selection
            
            int intSelection = Integer.parseInt(selection);  

            return intSelection;
        }
        
        
	private static double getDoubleValue() {
            
              
                String input = scan.next();
                
                // TODO Need to validate user double value entry
                
		return Double.parseDouble(input);
	}
        
}