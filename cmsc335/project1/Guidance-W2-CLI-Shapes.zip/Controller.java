
public class Controller {
    
    static double getAreaOfCircle(double radius) {
        
        return new Circle(radius).getArea();
    }
    
}
