
public class Shape {
    
    int numberOfDimensions;
    String name;
    
    Shape(int d, String n) {
        numberOfDimensions = d;
        name = n;
    }
    
    int getNumberOfDimensions() {
        return numberOfDimensions;
    }
   
    
    String getName() {
        return name;
    }
}

//-----------------------------------------------------------------------

class TwoDimensionalShape extends Shape {

        double dimension1;
        double dimension2;
        
        TwoDimensionalShape(double d1, double d2, String name) {
            super(2, name);
            dimension1 = d1;
            dimension2 = d2;
        }
	
	public double getArea() {
            return dimension1 * dimension2 ;
        } 
}


//-----------------------------------------------------------------------



class Circle extends TwoDimensionalShape{

	public Circle(double radius) {
		super(radius, radius * Math.PI, "Circle");
	}
}


