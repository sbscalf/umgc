SELECT customerID AS account_Number, lastName, firstName, streetAddress, zipCode
FROM CUSTOMER
ORDER BY customerID;