package scalf_homework2;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;
import java.util.UUID;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import com.jogamp.opengl.GL2;
import com.jogamp.opengl.GLAutoDrawable;
import com.jogamp.opengl.GLCapabilities;
import com.jogamp.opengl.GLEventListener;
import com.jogamp.opengl.awt.GLJPanel;

public class CMSC405P2 extends GLJPanel implements GLEventListener, KeyListener {
  public static final long serialVersionUID = UUID.randomUUID().getMostSignificantBits();

  private static JFrame window;
  private static CMSC405P2 panel;

  public static void main(String[] args) {
    initializeWindow();
    configureWindow();
    displayWindow();
  }

  private static void initializeWindow() {
    window = new JFrame("SCALF HOMEWORK 2");
    panel = new CMSC405P2();
  }

  private static void configureWindow() {
    window.setContentPane(panel);
    window.setJMenuBar(createMenuBar());
    window.pack();
    window.setLocationRelativeTo(null);
    window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    window.setResizable(false);
  }

  private static void displayWindow() {
    window.setVisible(true);
    panel.requestFocusInWindow();
  }

  public CMSC405P2() {
    super(new GLCapabilities(null));
    setPreferredSize(new Dimension(640, 480));
    setMinimumSize(new Dimension(640, 480));
    addGLEventListener(this);
    addKeyListener(this);
  }

  private static ActionListener menuListener = new ActionListener() {
    @Override
    public void actionPerformed(ActionEvent e) {
      if (e.getActionCommand().equalsIgnoreCase("Controls")) {
        displayControlsPane();
      } else if (e.getActionCommand().equalsIgnoreCase("About")) {
        displayAboutPane();
      }
    }

    private void displayControlsPane() {
      StringBuilder sb = new StringBuilder();
      sb.append(String.format("%13s  W/S or Up/Down Arrow%n", "X-ROTATION :"));
      sb.append(String.format("%13s  A/D or Left/Right Arrow%n", "Y-ROTATION :"));
      sb.append(String.format("%13s  Q/E or PageUp/PageDown%n", "Z-ROTATION :"));
      sb.append(String.format("%13s I and O%n", "ZOOM IN/OUT :"));
      sb.append(String.format("%13s  SPACE or HOME", "RESET :"));
      JOptionPane.showMessageDialog(window, sb.toString(), "Keyboard Controls",
          JOptionPane.PLAIN_MESSAGE);
    }

    private void displayAboutPane() {
      StringBuilder sb = new StringBuilder();
      String title = "Project 2: JOGL OpenGL Project";
      sb.append("Samuel B. Scalf\n\n");
      sb.append(
          "School of Cybersecurity and Information Technology, University of Maryland Global Campus\n");
      sb.append("CMSC 405: Computer Graphics\n");
      sb.append("Dr. Cynthia V. Marcello\n");
      sb.append("8 February 2022");
      JOptionPane.showMessageDialog(window, sb.toString(), title, JOptionPane.INFORMATION_MESSAGE);
    }
  };

  private static JMenuBar createMenuBar() {
    JMenuBar menuBar = new JMenuBar();
    JMenuItem controls = new JMenuItem("Controls");
    JMenuItem about = new JMenuItem("About");
    controls.addActionListener(menuListener);
    about.addActionListener(menuListener);
    menuBar.setLayout(new BorderLayout());
    menuBar.add(controls, BorderLayout.WEST);
    menuBar.add(about, BorderLayout.EAST);
    return menuBar;
  }

  @Override
  public void init(GLAutoDrawable drawable) {
    GL2 gl2 = drawable.getGL().getGL2();
    gl2.glMatrixMode(GL2.GL_PROJECTION);
    gl2.glOrtho(-1, 1, -1, 1, -1, 1);
    gl2.glMatrixMode(GL2.GL_MODELVIEW);
    gl2.glClearColor(0, 0, 0, 1);
    gl2.glEnable(GL2.GL_DEPTH_TEST);
  }

  @Override
  public void display(GLAutoDrawable drawable) {
    GL2 gl2 = drawable.getGL().getGL2();
    gl2.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT);
    gl2.glLoadIdentity();
    drawShapes(gl2);
  }

  double rotateX = 15;
  double rotateY = -15;
  double rotateZ = 0;
  double scale = 1;

  private void drawShapes(GL2 gl2) {
    gl2.glPushMatrix();
    gl2.glRotated(rotateZ, 0, 0, 1);
    gl2.glRotated(rotateY, 0, 1, 0);
    gl2.glRotated(rotateX, 1, 0, 0);
    CMSC405P2Transformation transformation = new CMSC405P2Transformation();

    transformation.setScale(0.1 * scale);
    transformation.setPoint(-5, 0, 5);
    drawShape(gl2, CMSC405P2Shape.TETRAHEDRON, transformation);

    transformation.setPoint(3, -6, 0);
    drawShape(gl2, CMSC405P2Shape.HOUSE, transformation);

    transformation.setPoint(0, 0, -5);
    drawShape(gl2, CMSC405P2Shape.OCTOHEDRON, transformation);

    transformation.setPoint(-5, -4, 0);
    drawShape(gl2, CMSC405P2Shape.PENCIL, transformation);

    transformation.setScale(0.01 * scale);
    transformation.setPoint(-30, -56, -30);
    drawShapeStrip(gl2, CMSC405P2Shape.TUNNEL, transformation);

    transformation.setScale(0.002 * scale);
    transformation.setPoint(200, -150, 100);
    drawShape(gl2, CMSC405P2Shape.DAHLIA, transformation);

    gl2.glPopMatrix();
  }

  private void drawShape(GL2 gl2, CMSC405P2Shape shape, CMSC405P2Transformation t) {
    gl2.glPushMatrix();
    gl2.glScaled(t.getScale(), t.getScale(), t.getScale());
    gl2.glTranslated(t.getX(), t.getY(), t.getZ());
    for (int i = 0; i < shape.faces.length; i++) {
      gl2.glColor3dv(shape.faceColors[i], 0);
      gl2.glBegin(GL2.GL_TRIANGLE_FAN);

      for (int j = 0; j < shape.faces[i].length; j++) {
        int vertexNum = shape.faces[i][j];
        gl2.glVertex3dv(shape.vertices[vertexNum], 0);
      }

      gl2.glEnd();
    }
    gl2.glPopMatrix();
  }

  // Clone of drawShape but using GL_TRIANGLE_STRIP instead of GL_TRIANGLE_FAN
  private void drawShapeStrip(GL2 gl2, CMSC405P2Shape shape, CMSC405P2Transformation t) {
    gl2.glPushMatrix();
    gl2.glScaled(t.getScale(), t.getScale(), t.getScale());
    gl2.glTranslated(t.getX(), t.getY(), t.getZ());
    for (int i = 0; i < shape.faces.length; i++) {
      gl2.glColor3dv(shape.faceColors[i], 0);
      gl2.glBegin(GL2.GL_TRIANGLE_STRIP);

      for (int j = 0; j < shape.faces[i].length; j++) {
        int vertexNum = shape.faces[i][j];
        gl2.glVertex3dv(shape.vertices[vertexNum], 0);
      }

      gl2.glEnd();
    }
    gl2.glPopMatrix();
  }

  @Override
  public void dispose(GLAutoDrawable arg0) {}

  @Override
  public void reshape(GLAutoDrawable arg0, int arg1, int arg2, int arg3, int arg4) {}

  // Modified from the IFSPolyhedron class in the jogl example files
  // Key bindings expanded to include W, A, S, D, Q, E, and SPACE
  @Override
  public void keyPressed(KeyEvent evt) {
    int key = evt.getKeyCode();
    if (key == KeyEvent.VK_LEFT || key == KeyEvent.VK_A)
      rotateY -= 15;
    else if (key == KeyEvent.VK_RIGHT || key == KeyEvent.VK_D)
      rotateY += 15;
    else if (key == KeyEvent.VK_DOWN || key == KeyEvent.VK_S)
      rotateX += 15;
    else if (key == KeyEvent.VK_UP || key == KeyEvent.VK_W)
      rotateX -= 15;
    else if (key == KeyEvent.VK_PAGE_UP || key == KeyEvent.VK_Q)
      rotateZ += 15;
    else if (key == KeyEvent.VK_PAGE_DOWN || key == KeyEvent.VK_E)
      rotateZ -= 15;
    else if (key == KeyEvent.VK_HOME || key == KeyEvent.VK_SPACE) {
      rotateX = 15;
      rotateY = -15;
      rotateZ = 0;
      scale = 1;
    } else if (key == KeyEvent.VK_I)
      scale += 0.1;
    else if (key == KeyEvent.VK_O)
      scale -= 0.1;
    repaint();
  }

  @Override
  public void keyTyped(KeyEvent e) {}

  @Override
  public void keyReleased(KeyEvent e) {}
}
