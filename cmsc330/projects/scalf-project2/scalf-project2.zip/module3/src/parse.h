#ifndef PARSE_H_
#define PARSE_H_

string parseName(stringstream& in);

#endif /* PARSE_H_ */
